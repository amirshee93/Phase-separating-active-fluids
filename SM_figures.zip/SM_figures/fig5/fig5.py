import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import AutoMinorLocator

# Set Parameters
plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'Helvetica'
ngrid = 1000
fontsize = 18
#cmap = plt.cm.plasma 
#cmap = plt.cm.viridis
#cmap = plt.cm.cividis 
#cmap = plt.cm.RdBu
cmap = plt.colormaps.get_cmap('Greys')

#colors = ["white", "blue"]  # You can add more colors in between if you want a more complex transition
#cmap = LinearSegmentedColormap.from_list("custom_cmap", colors)


fig = plt.figure(figsize=(6, 2))
ax1 = plt.subplot2grid((1, 2), (0, 0))
ax2 = plt.subplot2grid((1, 2), (0, 1))



#ax1.set_aspect('equal')
#ax2.set_aspect('equal')
#ax1.set_aspect('equal')
ax1.tick_params(labelsize=14)
ax2.tick_params(labelsize=14)

# For ax1
ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
ax1.tick_params(which='both', direction='in', top=True, right=True)  # This line ensures that ticks are shown on all sides and apply to both major and minor ticks.

# For ax2
ax2.xaxis.set_minor_locator(AutoMinorLocator(2))
ax2.yaxis.set_minor_locator(AutoMinorLocator(2))
ax2.tick_params(which='both', direction='in', top=True, right=True)  # Applies to both major and minor ticks.


# Adjust the left, right, bottom, and top margins of the figure
left_margin = 0.10   # Adjust this value as needed
right_margin = 0.95  # Adjust this value as needed
bottom_margin = 0.2 # Adjust this value as needed
top_margin = 0.96    # Adjust this value as needed
wspace = 0.65
hspace = 0.0
plt.subplots_adjust(left=left_margin, right=right_margin, bottom=bottom_margin, top=top_margin, wspace=wspace, hspace=hspace)


def read_two_column_file(file_name):
    with open(file_name, 'r') as data:
        x1, x2 = [], []
        for line in data:
            p = line.split()
            x1.append(float(p[0]))
            x2.append(float(p[1]))
    return x1, x2


rho0 = 1.0
wo = 1.0
won = 1.0
q = 1.0
alpha = -15.0

# Figure (a)
def function_lambda_real(D,Pe):
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = Pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    trace = -(q**2)*(A-(B/(1+q**2)))-(wo+won)
    m11 =  -(q**2)*(1.0-(B/(1+q**2)))-wo
    m22 = -(q**2)*D-won
    m12 = won
    m21 = -(q**2)*(-((Pe*(phi0-alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q**2)))+wo
    det = m11*m22 - m12*m21
    delta = (trace**2 - 4.0 * det)
    if delta <0:
        lambda_real_values = trace/2.0
    else:
        lambda_real_values = np.real((trace + np.sqrt(delta))/2.0)
    return lambda_real_values
def function_lambda_im(D,Pe):
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = Pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    trace = -(q**2)*(A-(B/(1+q**2)))-(wo+won)
    m11 =  -(q**2)*(1.0-(B/(1+q**2)))-wo
    m22 = -(q**2)*D-won
    m12 = won
    m21 = -(q**2)*(-((Pe*(phi0-alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q**2)))+wo
    det = m11*m22 - m12*m21
    delta = (trace**2 - 4.0 * det)
    if delta <0:
        lambda_im_values = np.sqrt(-delta)/2.0
    else:
        lambda_im_values = 0
    return lambda_im_values

D_values = np.linspace(0, 1, ngrid)
Pe_values = np.linspace(-4, 0, ngrid)
lambda_real = np.zeros((len(D_values), len(Pe_values)))
lambda_im = np.zeros((len(D_values), len(Pe_values)))
for j, D in enumerate(D_values):
    for i, Pe in enumerate(Pe_values):
        lambda_real[i, j] = function_lambda_real(D,Pe)
        lambda_im[i, j] = function_lambda_im(D,Pe)

cmesh = ax1.pcolormesh(D_values, Pe_values, lambda_im, shading='auto', cmap=cmap)
contour = ax1.contour(D_values, Pe_values, lambda_im, levels=[0], colors='grey', linestyles='dashed')
contour = ax1.contour(D_values, Pe_values, lambda_real, levels=[0], colors='r')
cbar = fig.colorbar(cmesh, ax=ax1, orientation='vertical', pad=0.02)
ax1.tick_params(which='major', direction='in', bottom=True, top=True, left=True, right=True)
ax1.tick_params(which='minor', direction='in', bottom=True, top=True, left=True, right=True)
# Optional: Set the size of the ticks and tick labels for the colorbar
cbar.ax.tick_params(direction="in", which='major', labelsize=fontsize, size=4)  # Colorbar ticks
cbar.ax.tick_params(direction="in", which='minor', labelsize=fontsize, size=3)  # Colorbar ticks
cbar.set_label(r'$\lambda_{\mathrm{Im}}$', fontsize=fontsize, labelpad=0)
ax1.set_xlim([0, 1])
ax1.set_ylim([-4, 0])
ax1.set_xlabel('$D$', fontsize=fontsize, labelpad=-2)
ax1.set_ylabel('$Pe$', fontsize=fontsize, labelpad=-2)
ax1.text(-0.3, 1.025, '(a)', transform=ax1.transAxes, fontsize=18, fontweight='bold', va='top')
ax1.text(0.4, 0.7, r'$\lambda_{\mathrm{Re}}<0$', transform=ax1.transAxes, fontsize=18, fontweight='bold', va='top', color='red')
ax1.text(0.04, 0.35, r'$\lambda_{\mathrm{Re}}>0$', transform=ax1.transAxes, fontsize=18, fontweight='bold', va='top', color='red')



rho0 = 1.0
wo = 1.0
Pe = -2.6
q = 1.0
alpha = -15.0

# Figure (b)
def function_lambda_real(D,won):
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = Pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    trace = -(q**2)*(A-(B/(1+q**2)))-(wo+won)
    m11 =  -(q**2)*(1.0-(B/(1+q**2)))-wo
    m22 = -(q**2)*D-won
    m12 = won
    m21 = -(q**2)*(-((Pe*(phi0-alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q**2)))+wo
    det = m11*m22 - m12*m21
    delta = (trace**2 - 4.0 * det)
    if delta <0:
        lambda_real_values = trace/2.0
    else:
        lambda_real_values = np.real((trace + np.sqrt(delta))/2.0)
    return lambda_real_values

def function_lambda_im(D,won):
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = Pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    trace = -(q**2)*(A-(B/(1+q**2)))-(wo+won)
    m11 =  -(q**2)*(1.0-(B/(1+q**2)))-wo
    m22 = -(q**2)*D-won
    m12 = won
    m21 = -(q**2)*(-((Pe*(phi0-alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q**2)))+wo
    det = m11*m22 - m12*m21
    delta = (trace**2 - 4.0 * det)
    if delta <0:
        lambda_im_values = np.sqrt(-delta)/2.0
    else:
        lambda_im_values = 0
    return lambda_im_values

D_values = np.linspace(0, 1, ngrid)
won_values = np.linspace(0, 3, ngrid)
lambda_real = np.zeros((len(D_values), len(won_values)))
lambda_im = np.zeros((len(D_values), len(won_values)))
for j, D in enumerate(D_values):
    for i, won in enumerate(won_values):
        lambda_real[i, j] = function_lambda_real(D,won)
        lambda_im[i, j] = function_lambda_im(D,won)

cmesh = ax2.pcolormesh(D_values, won_values, lambda_im, shading='auto', cmap=cmap)
contour = ax2.contour(D_values, won_values, lambda_im, levels=[0], colors='grey', linestyles='dashed')
contour = ax2.contour(D_values, won_values, lambda_real, levels=[0], colors='r')
cbar = fig.colorbar(cmesh, ax=ax2, orientation='vertical', pad=0.02)
ax2.tick_params(which='major', direction='in', bottom=True, top=True, left=True, right=True)
ax2.tick_params(which='minor', direction='in', bottom=True, top=True, left=True, right=True)
# Optional: Set the size of the ticks and tick labels for the colorbar
cbar.ax.tick_params(direction="in", which='major', labelsize=fontsize, size=4)  # Colorbar ticks
cbar.ax.tick_params(direction="in", which='minor', labelsize=fontsize, size=3)  # Colorbar ticks
cbar.set_label(r'$\lambda_{\mathrm{Im}}$', fontsize=fontsize, labelpad=2)
ax2.set_xlim([0, 1])
ax2.set_ylim([0, 2.5])
ax2.set_xlabel('$D$', fontsize=fontsize, labelpad=-2)
ax2.set_ylabel(r'$\omega_{\mathrm{on}}$', fontsize=fontsize, labelpad=2)
ax2.text(-0.4, 1.025, '(b)', transform=ax2.transAxes, fontsize=18, fontweight='bold', va='top')
ax2.text(0.45, 0.95, r'$\lambda_{\mathrm{Re}}<0$', transform=ax2.transAxes, fontsize=18, fontweight='bold', va='top', color='red')
ax2.text(0.15, 0.45, r'$\lambda_{\mathrm{Re}}>0$', transform=ax2.transAxes, fontsize=18, fontweight='bold', va='top', color='red')

# Adjust spacing and show the plot
#plt.tight_layout()
plt.show()

file_base_name = "fig5"  # change to your desired filename without extension
fig.savefig(f"{file_base_name}.png", dpi=600)   # PNG format