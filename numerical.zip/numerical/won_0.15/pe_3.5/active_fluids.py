import os
import time
import csv
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# Parameters
L = 2*np.pi         # Length of the domain
dx = 0.01 # Grid spacing
m = int(L / dx)         # Number of grid points
al = 0.1         # Diffusion coefficient
rs = 10.0
wo = 1.0       
won = 0.15      
pe = 3.50        # Peclet number
dt = 0.01        # Time step
kappa = dt / dx**2
gam = dt / (2.0 * dx)

# Discretized space
xx = np.linspace(0, L, m)
#print(xx)

cao = np.full(m, won/(won+wo))    
cpo = np.full(m, wo/(won+wo))       
vo = 0.0001 * np.sin(xx)  

# Copy initial conditions to the 'old' arrays
caoo = cao.copy()
cpoo = cpo.copy()
voo = np.zeros(m)     


def thomas(aa, bb, cc, ff):
    # Initialize necessary arrays
    gam2 = np.zeros(m, dtype=np.float64)

    # Step 1: Forward elimination
    bb[0] = 1.0 / bb[0]
    gam2[0] = -aa[0] * bb[0]
    aa[0] = ff[0] * bb[0]

    for i in range(1, m - 2):
        im1 = i - 1
        cc[im1] = cc[im1] * bb[im1]
        coeff = bb[i] - aa[i] * cc[im1]
        bb[i] = 1.0 / coeff
        gam2[i] = -aa[i] * gam2[im1] * bb[i]
        aa[i] = (ff[i] - aa[i] * aa[im1]) * bb[i]

    gam2[m - 3] = gam2[m - 3] - cc[m - 3] * bb[m - 3]

    # Step 2: Back substitution
    ff[m - 3] = aa[m - 3]
    bb[m - 3] = gam2[m - 3]

    for k1 in range(1, m - 2):
        k = m - 3 - k1
        k2 = k + 1
        ff[k] = aa[k] - cc[k] * ff[k2]
        bb[k] = gam2[k] - cc[k] * bb[k2]

    k1 = m - 2
    k2 = k1 - 1
    zaa = ff[k1] - cc[k1] * ff[0] - aa[k1] * ff[k2]
    zaa = zaa / (bb[k1] + aa[k1] * bb[k2] + cc[k1] * bb[0])
    ff[k1] = zaa

    for i in range(m - 2):
        ff[i] = ff[i] + bb[i] * zaa

    ff[m - 1] = ff[0]

    return ff



start_time = time.time()
steps = 100
skip_steps = 0
max_steps = skip_steps + 1000
output_file = open("input_output.csv", "w")
csv_writer = csv.writer(output_file)


# Setup the plot
fig, ax1 = plt.subplots()
ax2 = ax1.twinx()
line1, = ax1.plot(xx, cao, 'b', label='$\\psi(x,t)$')
line2, = ax1.plot(xx, cpo, 'g', label='$\\phi(x,t)$')
line3, = ax2.plot(xx, vo, 'r', label='$v(x,t)$', linestyle='--')
ax1.set_xlabel('Position')
ax1.set_ylabel('Concentration')
ax2.set_ylabel('Velocity')
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')
ax1.set_title('Advection-Diffusion with Dynamic Velocity')


def mainloop(t):
    global m, caoo, cpoo, voo, cao, cpo, vo
    for u in range(steps):

        source = np.zeros(m)  # Initialize the source array
        for j in range(m):
            # Periodic boundary conditions
            jp1 = j + 1 if j < m - 1 else 1
            jm1 = j - 1 if j > 0 else m - 1

            # Calculate divergence of velocity and off rates
            div_vel = (vo[jp1] - vo[jm1]) / (2.0 * dx)
            woff = wo * np.exp(rs * div_vel)
            # Update the source term
            source[j] = (3.0 / 2.0) * (woff * cao[j] - won * cpo[j]) - (1.0 / 2.0) * (woff * caoo[j] - won * cpoo[j])

        aa = np.zeros(m)
        bb = np.zeros(m)
        cc = np.zeros(m)
        ff = np.zeros(m)

        # Set up the coefficients for the tridiagonal matrix
        aa.fill(-(9.0 / 16.0) * kappa)
        bb.fill(1.0 + (9.0 / 8.0) * kappa)
        cc.fill(-(9.0 / 16.0) * kappa)

        # Active concentration evolution
        for j in range(m):
            # Periodic boundary conditions
            jp1 = j + 1 if j < m - 1 else 1
            jm1 = j - 1 if j > 0 else m - 1

            # Calculate diffusion and advection terms
            diffusion1 = kappa * (cao[jp1] + cao[jm1] - 2.0 * cao[j])
            diffusion2 = kappa * (caoo[jp1] + caoo[jm1] - 2.0 * caoo[j])
            advection1 = -gam * cao[j] * (vo[jp1] - vo[jm1]) - gam * vo[j] * (cao[jp1] - cao[jm1])
            advection2 = -gam * caoo[j] * (voo[jp1] - voo[jm1]) - gam * voo[j] * (caoo[jp1] - caoo[jm1])

            # Update ff
            ff[j] = cao[j] + (3.0 / 2.0) * advection1 - (1.0 / 2.0) * advection2 + (3.0 / 8.0) * diffusion1 + (1.0 / 16.0) * diffusion2 - dt * source[j]

        # Solve the tridiagonal system using the Thomas algorithm
        # Assuming thomas is a function equivalent to the Fortran subroutine
        ca = thomas(aa, bb, cc, ff)


        aa = np.zeros(m)
        bb = np.zeros(m)
        cc = np.zeros(m)
        ff = np.zeros(m)

        # Set up the coefficients for the tridiagonal matrix for passive concentration
        aa.fill(-al * (9.0 / 16.0) * kappa)
        bb.fill(1.0 + al * (9.0 / 8.0) * kappa)
        cc.fill(-al * (9.0 / 16.0) * kappa)

        # Passive concentration evolution
        for j in range(m):
            # Periodic boundary conditions
            jp1 = j + 1 if j < m - 1 else 1
            jm1 = j - 1 if j > 0 else m - 1

            # Calculate diffusion and advection terms for passive concentration
            diffusion1 = al * kappa * (cpo[jp1] + cpo[jm1] - 2.0 * cpo[j])
            diffusion2 = al * kappa * (cpoo[jp1] + cpoo[jm1] - 2.0 * cpoo[j])
            advection1 = -gam * cpo[j] * (vo[jp1] - vo[jm1]) - gam * vo[j] * (cpo[jp1] - cpo[jm1])
            advection2 = -gam * cpoo[j] * (voo[jp1] - voo[jm1]) - gam * voo[j] * (cpoo[jp1] - cpoo[jm1])

            # Update ff for passive concentration
            ff[j] = cpo[j] + (3.0 / 2.0) * advection1 - (1.0 / 2.0) * advection2 + (3.0 / 8.0) * diffusion1 + (1.0 / 16.0) * diffusion2 + dt * source[j]

        # Solve the tridiagonal system using the Thomas algorithm for passive concentration
        # Assuming thomas is a function equivalent to the Fortran subroutine
        cp = thomas(aa, bb, cc, ff)

        aa = np.ones(m)
        bb = np.full(m, -(2.0 + dx * dx))
        cc = np.ones(m)
        ff = np.zeros(m)

        # Force balance equation
        for j in range(m):
            # Periodic boundary conditions
            jp1 = j + 1 if j < m - 1 else 1
            jm1 = j - 1 if j > 0 else m - 1

            # Calculate the force balance
            ff[j] = -(pe / ((1.0 + cao[j]) ** 2)) * (cao[jp1] - cao[jm1]) * (dx / 2.0)

        # Solve the tridiagonal system using the Thomas algorithm
        # Assuming thomas is a function equivalent to the Fortran subroutine
        v = thomas(aa, bb, cc, ff)  # Update velocity

        # Update for next time step
        caoo = cao.copy()
        cpoo = cpo.copy()
        voo = vo.copy()
        cao = ca.copy()
        cpo = cp.copy()
        vo = v.copy()

    print(t*steps)
    if t >= skip_steps and t<=max_steps:
        data_folder = "dynamics_data"
        if not os.path.exists(data_folder):
            os.makedirs(data_folder)
        file_name = f"{data_folder}/concentrations_velocity_{t-skip_steps}.csv"
        np.savetxt(file_name, np.column_stack((xx, cao, cpo, vo)), delimiter=',', header='xval, caval, cpval, vval', comments='')


    line1.set_ydata(cao)  # Update data for C1
    line2.set_ydata(cpo)  # Update data for C2
    line3.set_ydata(vo)   # Update data for Velocity

    # Calculate the new y-axis limits
    min_c = min(cao.min(), cpo.min())
    max_c = max(cao.max(), cpo.max())
    min_v = vo.min()
    max_v = vo.max()

    # Update y-axis limits for concentration (ax1)
    ax1.set_ylim(min_c - 0.1 * abs(min_c), max_c + 0.1 * abs(max_c))

    # Update y-axis limits for velocity (ax2)
    ax2.set_ylim(min_v - 0.1 * abs(min_v), max_v + 0.1 * abs(max_v))


    return line1, line2, line3

# Setup and show the plot
#ani = FuncAnimation(fig, mainloop, interval=1, save_count=100, cache_frame_data=False)
#plt.show()
#output_file.close()

if __name__ == '__main__':
    csv_writer.writerows([
        ["alpha:", str(al)],
        ["won:", str(won)],
        ["rs:", str(rs)],
        ["wo:", str(wo)],
        ["Time step:", str(dt)],
        ["Time steps jump:", str(steps)],
        ["Time steps skip:", str(skip_steps)],
        ["Total time steps:", str(max_steps)],
    ])
    output_file.flush()
    for t in range(max_steps):
        mainloop(t)

    # Calculate the elapsed time
    elapsed_time = time.time() - start_time

    # Write the elapsed time to the CSV file
    csv_writer.writerow(["Elapsed Time:", elapsed_time])
    output_file.flush()

    # Close the output file
    output_file.close()
