import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.animation import FuncAnimation
import matplotlib.animation as animation
from matplotlib.ticker import AutoMinorLocator, MultipleLocator

# Your setup code here
fontsize = 18
cmap = plt.cm.RdBu
plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'Helvetica'
plt.rcParams['text.latex.preamble'] = r'\usepackage{amsmath}\usepackage{xcolor}'


num_files = 1000
file_prefix = "concentrations_velocity_"
data_folder = "../../numerics/one_dimension/won_0.5/pe_3.0/dynamics_data"
file_extension = ".csv"

# Create figure and axes
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(4, 3))

# Adjust subplot parameters to give specified padding
plt.subplots_adjust(left=0.18, right=0.96, top=0.88, bottom=0.15, wspace=0.0, hspace=0.2)

cover_texts = []

def plot_cover_page(frame_num):
    ax1.clear()
    ax2.clear()
    ax1.axis('off')
    ax2.axis('off')
    text1 = fig.text(0.5, 0.6, 'Phase~separated~stationary~pattern', ha="center", va="center", fontsize=fontsize-2)
    text2 = fig.text(0.5, 0.5, 'Advection~diffusion~with~mechanical~turnover', ha="center", va="center", fontsize=fontsize-5)
    text3 = fig.text(0.5, 0.3, r'$\omega_{\mathrm{on}}=0.5,~Pe=3.0$', ha="center", va="center", fontsize=fontsize-8)

    cover_texts.extend([text1, text2, text3])
    return ax1, ax2

def init():
    """Initial setup of the plot."""
    ax1.clear()
    ax2.clear()
    # Set x-axis ticks at 0, pi, and 2pi
    tick_positions = [0, np.pi, 2 * np.pi]
    tick_labels = [r'$0$', r'$\pi$', r'$2\pi$']
    for ax in (ax1, ax2):
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(tick_labels)
        
        # Mirroring ticks on both top and bottom of the plot
        ax.tick_params(axis='x', which='both', top=True, bottom=True, labelbottom=True, direction='in', labelsize=fontsize)
        ax.tick_params(axis='y', which='both', left=True, right=True, labelleft=True, direction='in', labelsize=fontsize)
        
        minor_locator = ticker.AutoMinorLocator(2)
        ax.yaxis.set_minor_locator(minor_locator)

        ax.xaxis.set_minor_locator(MultipleLocator(np.pi / 2))


    ax2.set_xlabel('$x$', fontsize=fontsize, labelpad=-5)
    #ax1.set_ylabel(r'$\psi,\phi$', fontsize=fontsize)
    ax2.set_ylabel('$v$', fontsize=fontsize)


    ax1.text(0.01, 0.95, '(a)', transform=ax1.transAxes, fontsize=fontsize, fontweight='bold', va='top')
    ax2.text(0.01, 0.95, '(b)', transform=ax2.transAxes, fontsize=fontsize, fontweight='bold', va='top')

def update(t):
    """Update the plot for animation frame t."""
    ax1.clear()  # Clear the previous plot
    ax2.clear()  # Clear the previous plot

    ax1.set_title(f"$t={t+1}$", fontsize=fontsize-2)
    
    # Reapply the settings to the axes after clearing, including mirrored ticks
    tick_positions = [0, np.pi, 2 * np.pi]
    tick_labels = [r'$0$', r'$\pi$', r'$2\pi$']
    for ax in (ax1, ax2):
        ax.set_xticks(tick_positions)        
        # Mirroring ticks on both top and bottom of the plot
        ax.tick_params(axis='y', which='both', left=True, right=True, labelleft=True, direction='in', labelsize=fontsize)
        
        minor_locator = ticker.AutoMinorLocator(2)
        ax.yaxis.set_minor_locator(minor_locator)

        ax.xaxis.set_minor_locator(MultipleLocator(np.pi / 2))
    ax1.tick_params(axis='x', which='both', top=True, bottom=True, labelbottom=False, direction='in', labelsize=fontsize)
    ax2.tick_params(axis='x', which='both', top=True, bottom=True, labelbottom=True, direction='in', labelsize=fontsize)


    ax2.set_xticklabels(tick_labels)

    ax2.set_xlabel('$x$', fontsize=fontsize, labelpad=-5)
    #ax1.set_ylabel(r'$\textcolor{red}{\psi},\textcolor{blue}{\phi}$', fontsize=fontsize, labelpad=5)
    ax2.set_ylabel('$v$', fontsize=fontsize, labelpad=-15)

    ax1.text(-0.15, 0.4, r'$\psi,~$', transform=ax1.transAxes, fontsize=18, fontweight='bold', va='top', color='darkred', rotation=90)
    ax1.text(-0.15, 0.65, r'$\phi$', transform=ax1.transAxes, fontsize=18, fontweight='bold', va='top', color='darkblue', rotation=90)

    ax1.set_ylim(0, 1.15)
    ax2.set_ylim(-0.35, 0.35)
    ax1.set_xlim(0, 2*np.pi)
    ax2.set_xlim(0, 2*np.pi)


    ax1.text(0.01, 0.95, '(a)', transform=ax1.transAxes, fontsize=fontsize-2, va='top')
    ax2.text(0.01, 0.95, '(b)', transform=ax2.transAxes, fontsize=fontsize-2, va='top')

    # Load and plot the data for the current frame
    file_name = f"{data_folder}/{file_prefix}{t}{file_extension}"
    if os.path.exists(file_name):
        data = np.loadtxt(file_name, delimiter=',', skiprows=1)
        xx, ca, cp, v = data[:, 0], data[:, 1], data[:, 2], data[:, 3]
        ax1.plot(xx, ca, 'darkred', linewidth=2)
        ax1.plot(xx, cp, 'darkblue', linewidth=1)
        ax2.plot(xx, v, 'k', linewidth=2)

        ax1.fill_between(xx, 0, ca, color='darkred', alpha=0.1)
        ax1.fill_between(xx, 0, cp, color='darkblue', alpha=0.1)

def combined_plot(t):
    if t == 0:
        return plot_cover_page(t)
    else:
        if cover_texts:
            for text in cover_texts:
                text.set_visible(False)
        return update(t - 1)

# Create animation
ani = FuncAnimation(fig, combined_plot, frames=range(num_files + 1), init_func=init, blit=False)

# Save animation
file_base_name = "Movie3"
Writer = animation.writers['ffmpeg']
writer = Writer(fps=30, metadata=dict(artist='Me'), bitrate=1800)
ani.save(f"{file_base_name}.mp4", writer=writer)

plt.close()  # Close the figure to prevent it from displaying in the notebook
