import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker




fontsize = 24
#cmap = "viridis"  # Choose a colormap
cmap = plt.cm.RdBu
colorbar_width = 0.02  # Set the width of the color bar
colorbar_pad = 0.01    # Set the space between the plot and color bar
# Set Parameters
plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'Helvetica'


# Parameters
num_files = 1000  # Total number of files
file_prefix = "concentrations_velocity_"  # Prefix for the file names
data_folder = "../../numerics/one_dimension/won_0.5/pe_2.6/dynamics_data"  # Folder where the files are located
file_extension = ".csv"

# Initialize lists to store data
time_steps = range(num_files)
xx = []
concentration1 = []
concentration2 = []
velocity = []

# Read files and extract data
for t in time_steps:
    file_name = f"{data_folder}/{file_prefix}{t}{file_extension}"
    if os.path.exists(file_name):
        data = np.loadtxt(file_name, delimiter=',', skiprows=1)  # Assuming there is a header row
        xx.append(data[:, 0])  # Assuming second column is first concentration
        concentration1.append(data[:, 1])  # Assuming second column is first concentration
        concentration2.append(data[:, 2])  # Assuming third column is second concentration
        velocity.append(data[:, 3])  # Assuming fourth column is velocity

# Convert lists to numpy arrays and transpose them
concentration1 = np.array(concentration1).T
concentration2 = np.array(concentration2).T
velocity = np.array(velocity).T

# Create subplots
fig = plt.figure(figsize=(8, 6))
left_margin = 0.08
right_margin = 0.88
bottom_margin = 0.10
top_margin = 0.98
wspace = 0.0
hspace = 0.15
plt.subplots_adjust(left=left_margin, right=right_margin, bottom=bottom_margin, top=top_margin, wspace=wspace, hspace=hspace)
ax1 = plt.subplot2grid((3, 1), (0, 0))
ax2 = plt.subplot2grid((3, 1), (1, 0))
ax3 = plt.subplot2grid((3, 1), (2, 0))
ax1.tick_params(labelsize=fontsize)
ax2.tick_params(labelsize=fontsize)
ax3.tick_params(labelsize=fontsize)
minor_locator = ticker.AutoMinorLocator(4)  # Set minor tick frequency
ax1.xaxis.set_minor_locator(minor_locator)
ax2.xaxis.set_minor_locator(minor_locator)
ax3.xaxis.set_minor_locator(minor_locator)

# Set x-axis ticks at 0, pi, and 2pi
tick_positions = [0, np.pi, 2 * np.pi]
tick_labels = [r'$0$', r'$\pi$', r'$2\pi$']
ax1.set_yticks(tick_positions)
ax1.set_yticklabels(tick_labels)
ax2.set_yticks(tick_positions)
ax2.set_yticklabels(tick_labels)
ax3.set_yticks(tick_positions)
ax3.set_yticklabels(tick_labels)
minor_locator = ticker.AutoMinorLocator(2)  # Set minor tick frequency
ax1.yaxis.set_minor_locator(minor_locator)
ax2.yaxis.set_minor_locator(minor_locator)
ax3.yaxis.set_minor_locator(minor_locator)
ax1.text(0.01, 0.95, '(a)', transform=ax1.transAxes, fontsize=fontsize, fontweight='bold', va='top')
ax2.text(0.01, 0.95, '(b)', transform=ax2.transAxes, fontsize=fontsize, fontweight='bold', va='top')
ax3.text(0.01, 0.95, '(c)', transform=ax3.transAxes, fontsize=fontsize, fontweight='bold', va='top')







# Plot kymographs
# Calculate min and max of xx
xx_min = np.min(xx)
xx_max = np.max(xx)

# Calculate the extent
extent = [0, num_files - 1, xx_min, xx_max]

im1 = ax1.imshow(concentration1, aspect='auto', origin='lower', cmap=cmap, extent=extent)
cbar1 = plt.colorbar(im1, ax=ax1, fraction=colorbar_width, pad=colorbar_pad)
cbar1.ax.set_ylabel('$\\psi$', fontsize=fontsize, labelpad=5)
cbar1.ax.tick_params(direction='in', labelsize=fontsize)  # Set color bar ticks inward
ax1.set_ylabel('$x$', fontsize=fontsize,labelpad=-5)
ax1.tick_params(which='major', direction='in', bottom=True, top=True, left=True, right=True)
ax1.tick_params(which='minor', direction='in', bottom=True, top=True, left=True, right=True)

im2 = ax2.imshow(concentration2, aspect='auto', origin='lower', cmap=cmap, extent=extent)
cbar2 = plt.colorbar(im2, ax=ax2, fraction=colorbar_width, pad=colorbar_pad)
cbar2.ax.set_ylabel('$\\phi$', fontsize=fontsize, labelpad=5)
cbar2.ax.tick_params(direction='in', labelsize=fontsize)  # Set color bar ticks inward
ax2.set_ylabel('$x$', fontsize=fontsize,labelpad=-5)
ax2.tick_params(which='major', direction='in', bottom=True, top=True, left=True, right=True)
ax2.tick_params(which='minor', direction='in', bottom=True, top=True, left=True, right=True)

ax1.set_xticklabels([])
ax2.set_xticklabels([])

im3 = ax3.imshow(velocity, aspect='auto', origin='lower', cmap=cmap, extent=extent)
cbar3 = plt.colorbar(im3, ax=ax3, fraction=colorbar_width, pad=colorbar_pad)
cbar3.ax.set_ylabel('$v$', fontsize=fontsize, labelpad=-15)
cbar3.ax.tick_params(direction='in', labelsize=fontsize)  # Set color bar ticks inward
ax3.set_xlabel('$t$', fontsize=fontsize,labelpad=-5)
ax3.set_ylabel('$x$', fontsize=fontsize,labelpad=-5)
ax3.tick_params(which='major', direction='in', bottom=True, top=True, left=True, right=True)
ax3.tick_params(which='minor', direction='in', bottom=True, top=True, left=True, right=True)



# Adjust layout and show/save the plot
#plt.tight_layout()
plt.show()
file_base_name = "fig2"  # change to your desired filename without extension
fig.savefig(f"{file_base_name}.png", dpi=600)   # PNG format