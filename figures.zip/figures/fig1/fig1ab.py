import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import AutoMinorLocator, MultipleLocator


# Set Parameters
plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'Helvetica'
ngrid = 1000
fontsize = 22
#cmap = plt.cm.plasma 
#cmap = plt.cm.viridis
#cmap = plt.cm.cividis 
#cmap = plt.cm.RdBu
cmap = plt.colormaps.get_cmap('Greys')

#colors = ["white", "blue"]  # You can add more colors in between if you want a more complex transition
#cmap = LinearSegmentedColormap.from_list("custom_cmap", colors)


fig = plt.figure(figsize=(8, 3))
ax1 = plt.subplot2grid((1, 2), (0, 0))
ax2 = plt.subplot2grid((1, 2), (0, 1))



#ax1.set_aspect('equal')
#ax2.set_aspect('equal')
#ax1.set_aspect('equal')
ax1.tick_params(labelsize=fontsize-5)
ax2.tick_params(labelsize=fontsize-5)

# For ax1
ax1.xaxis.set_minor_locator(AutoMinorLocator(2))
ax1.yaxis.set_minor_locator(AutoMinorLocator(2))
ax1.tick_params(which='both', direction='in', top=True, right=True)  # This line ensures that ticks are shown on all sides and apply to both major and minor ticks.

# For ax2
ax2.yaxis.set_major_locator(MultipleLocator(0.5))
ax2.xaxis.set_minor_locator(AutoMinorLocator(2))
ax2.yaxis.set_minor_locator(AutoMinorLocator(2))
ax2.tick_params(which='both', direction='in', top=True, right=True)  # Applies to both major and minor ticks.


# Adjust the left, right, bottom, and top margins of the figure
left_margin = 0.065   # Adjust this value as needed
right_margin = 0.95  # Adjust this value as needed
bottom_margin = 0.17 # Adjust this value as needed
top_margin = 0.96    # Adjust this value as needed
wspace = 0.35
hspace = 0.0
plt.subplots_adjust(left=left_margin, right=right_margin, bottom=bottom_margin, top=top_margin, wspace=wspace, hspace=hspace)


def read_two_column_file(file_name):
    with open(file_name, 'r') as data:
        x1, x2 = [], []
        for line in data:
            p = line.split()
            x1.append(float(p[0]))
            x2.append(float(p[1]))
    return x1, x2


D = 0.1
rho0 = 1.0
wo = 1.0
won = 1.0
alpha = 10.0

# Figure (a)
def function_lambda_real(q,pe):
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    trace = -(q**2)*(A-(B/(1+q**2)))-(wo+won)
    m11 =  -(q**2)*(1.0-(B/(1+q**2)))-wo
    m22 = -(q**2)*D-won
    m12 = won
    m21 = -(q**2)*(-((pe*(phi0-alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q**2)))+wo
    det = m11*m22 - m12*m21
    delta = (trace**2 - 4.0 * det)
    if delta <0:
        lambda_real_values = trace/2.0
    else:
        lambda_real_values = np.real((trace + np.sqrt(delta))/2.0)
    return lambda_real_values

def function_lambda_im(q,pe):
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    trace = -(q**2)*(A-(B/(1+q**2)))-(wo+won)
    m11 =  -(q**2)*(1.0-(B/(1+q**2)))-wo
    m22 = -(q**2)*D-won
    m12 = won
    m21 = -(q**2)*(-((pe*(phi0-alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q**2)))+wo
    det = m11*m22 - m12*m21
    delta = (trace**2 - 4.0 * det)
    if delta <0:
        lambda_im_values = np.sqrt(-delta)/2.0
    else:
        lambda_im_values = 0
    return lambda_im_values

q_values = np.linspace(0, 3, ngrid)
pe_values = np.linspace(0, 5, ngrid)
lambda_real = np.zeros((len(q_values), len(pe_values)))
lambda_im = np.zeros((len(q_values), len(pe_values)))
for j, q in enumerate(q_values):
    for i, pe in enumerate(pe_values):
        lambda_real[i, j] = function_lambda_real(q,pe)
        lambda_im[i, j] = function_lambda_im(q,pe)

cmesh = ax1.pcolormesh(q_values, pe_values, lambda_im, shading='auto', cmap=cmap)
contour = ax1.contour(q_values, pe_values, lambda_im, levels=[0], colors='grey', linestyles='dashed')
contour = ax1.contour(q_values, pe_values, lambda_real, levels=[0], colors='black')
cbar = fig.colorbar(cmesh, ax=ax1, orientation='vertical', pad=0.02)
ax1.tick_params(which='major', direction='in', bottom=True, top=True, left=True, right=True)
ax1.tick_params(which='minor', direction='in', bottom=True, top=True, left=True, right=True)
# Optional: Set the size of the ticks and tick labels for the colorbar
cbar.ax.tick_params(direction="in", which='major', labelsize=fontsize, size=4)  # Colorbar ticks
cbar.ax.tick_params(direction="in", which='minor', labelsize=fontsize, size=3)  # Colorbar ticks
cbar.set_label(r'$\lambda_{\mathrm{Im}}$', fontsize=fontsize, labelpad=0)
ax1.set_xlim([0, 3])
ax1.set_ylim([0, 5])
ax1.set_xlabel('$q$', fontsize=fontsize, labelpad=-5)
ax1.set_ylabel('$Pe$', fontsize=fontsize, labelpad=-2)
ax1.text(0.05, 0.98, '(a)', transform=ax1.transAxes, fontsize=fontsize, fontweight='bold', va='top')
ax1.text(0.28, 0.75, r'$\lambda_{\mathrm{Re}}>0$', transform=ax1.transAxes, fontsize=fontsize, fontweight='bold', va='top', color='red', rotation = 0)
ax1.text(0.25, 0.50, r'$\lambda_{\mathrm{Re}}<0$', transform=ax1.transAxes, fontsize=fontsize, fontweight='bold', va='top', color='red')



D = 0.1
rho0 = 1.0
wo = 1.0
pe = 2.75
alpha = 10.0

# Figure (b)
def function_lambda_real(q,won):
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    trace = -(q**2)*(A-(B/(1+q**2)))-(wo+won)
    m11 =  -(q**2)*(1.0-(B/(1+q**2)))-wo
    m22 = -(q**2)*D-won
    m12 = won
    m21 = -(q**2)*(-((pe*(phi0-alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q**2)))+wo
    det = m11*m22 - m12*m21
    delta = (trace**2 - 4.0 * det)
    if delta <0:
        lambda_real_values = trace/2.0
    else:
        lambda_real_values = (trace + np.sqrt(delta))/2.0
    return lambda_real_values


def function_lambda_im(q,won):
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    trace = -(q**2)*(A-(B/(1+q**2)))-(wo+won)
    m11 =  -(q**2)*(1.0-(B/(1+q**2)))-wo
    m22 = -(q**2)*D-won
    m12 = won
    m21 = -(q**2)*(-((pe*(phi0-alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q**2)))+wo
    det = m11*m22 - m12*m21
    delta = (trace**2 - 4.0 * det)
    if delta <0:
        lambda_im_values = np.sqrt(-delta)/2.0
    else:
        lambda_im_values = 0
    return lambda_im_values

q_values = np.linspace(0, 2, ngrid)
won_values = np.linspace(0, 2, ngrid)
lambda_real = np.zeros((len(q_values), len(won_values)))
lambda_im = np.zeros((len(q_values), len(won_values)))
for j, q in enumerate(q_values):
    for i, won in enumerate(won_values):
        lambda_real[i, j] = function_lambda_real(q,won)
        lambda_im[i, j] = function_lambda_im(q,won)

cmesh = ax2.pcolormesh(q_values, won_values, lambda_im, shading='auto', cmap=cmap)
contour = ax2.contour(q_values, won_values, lambda_im, levels=[0], colors='grey', linestyles='dashed')
contour = ax2.contour(q_values, won_values, lambda_real, levels=[0], colors='black')
cbar = fig.colorbar(cmesh, ax=ax2, orientation='vertical', pad=0.02)
ax2.tick_params(which='major', direction='in', bottom=True, top=True, left=True, right=True)
ax2.tick_params(which='minor', direction='in', bottom=True, top=True, left=True, right=True)
# Optional: Set the size of the ticks and tick labels for the colorbar
cbar.ax.tick_params(direction="in", which='major', labelsize=fontsize, size=4)  # Colorbar ticks
cbar.ax.tick_params(direction="in", which='minor', labelsize=fontsize, size=3)  # Colorbar ticks
cbar.set_label(r'$\lambda_{\mathrm{Im}}$', fontsize=fontsize, labelpad=2)
ax2.set_xlim([0, 2])
ax2.set_ylim([-0.02, 2])
ax2.set_xlabel('$q$', fontsize=fontsize, labelpad=-5)
ax2.set_ylabel(r'$\omega_{\mathrm{on}}$', fontsize=fontsize, labelpad=2)
ax2.text(0.05, 0.98, '(b)', transform=ax2.transAxes, fontsize=fontsize, fontweight='bold', va='top')
#ax2.text(0.025, 0.985, r'$\lambda_{\mathrm{Re}}>0$', transform=ax2.transAxes, fontsize=fontsize, fontweight='bold', va='top',rotation=90, color='red')
ax2.text(0.20, 0.30, r'$\lambda_{\mathrm{Re}}>0$', transform=ax2.transAxes, fontsize=fontsize, fontweight='bold', va='top', rotation=0, color='red')
ax2.text(0.5, 0.94, r'$\lambda_{\mathrm{Re}}<0$', transform=ax2.transAxes, fontsize=fontsize, fontweight='bold', va='top', rotation=0, color='red')

# Adjust spacing and show the plot
#plt.tight_layout()
plt.show()

file_base_name = "fig1ab"  # change to your desired filename without extension
fig.savefig(f"{file_base_name}.png", dpi=600)   # PNG format