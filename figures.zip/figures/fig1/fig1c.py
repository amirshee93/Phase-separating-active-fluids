import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'Helvetica'

fontsize = 22
labelsize = 18

# Define physical system parameters
L = 2 * np.pi   # system size
a = 0.2         # microscopic cutoff
q_min = 2 * np.pi / L          # smallest relevant wave number
q_max_endpoint = 2 * np.pi / a # largest relevant wave number

# Model parameters
rho0 = 1.0
wo = 1.0         # omega_off
alpha = 10.0
D = 0.1

# Define the q-dependent growth rate function (real part) 
def function_lambda_real_q(q_val, won, Pe):
    """
    Computes the real part of the growth rate λ(q) for a given q, ω_on (won), and Pe.
    """
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = Pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    m11 = -(q_val**2) * (1.0 - (B/(1+q_val**2))) - wo
    m22 = -(q_val**2)*D - won
    m12 = won
    m21 = -(q_val**2)*(-((Pe*(phi0 - alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q_val**2))) + wo
    trace = m11 + m22
    det = m11*m22 - m12*m21
    delta = trace**2 - 4.0 * det
    if delta < 0:
        lam = trace/2.0
    else:
        lam = np.real((trace + np.sqrt(delta))/2.0)
    return lam

# Set up grids for ω_on (won) and Pe
won_values = np.linspace(0.0, 1.1, 200)  # adjust resolution as needed
Pe_values  = np.linspace(1.98, 3.75, 200)

# Create an array to store q_max for each (won, Pe)
qmax_array = np.zeros((len(Pe_values), len(won_values)))

# Number of q-samples in the physically relevant range:
Nq = 1000
q_vals = np.linspace(q_min, q_max_endpoint, Nq)

# Loop over parameter grid to compute q_max for each (won, Pe)
for j, won in enumerate(won_values):
    for i, Pe in enumerate(Pe_values):
        # Compute λ(q) over q_vals
        lam_vals = np.array([function_lambda_real_q(q, won, Pe) for q in q_vals])
        # Find q_max: the q that gives the maximum growth rate
        max_idx = np.argmax(lam_vals)
        qmax_array[i, j] = q_vals[max_idx]

# Plot the heat map of q_max on the won-Pe plane
fig, ax = plt.subplots(figsize=(8, 4))
c = ax.contourf(won_values, Pe_values, qmax_array, 200, cmap='RdBu')
ax.set_xlabel(r'$\omega_{\mathrm{on}}$', fontsize=fontsize)
ax.set_ylabel(r'$Pe$', fontsize=fontsize)
cb = fig.colorbar(c, ax=ax)
cb.set_label(r'$q_{\rm max}$', fontsize=fontsize)
# Set the colorbar ticks to point inward:
cb.ax.tick_params(which='both', direction='in', labelsize=labelsize)

ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
ax.tick_params(which='both', direction='in', labelsize=labelsize)


# Label the figure as (c) in the upper left corner
ax.text(0.05, 0.95, r'(c)', transform=ax.transAxes, fontsize=20, 
        verticalalignment='top', horizontalalignment='left')

plt.tight_layout()
plt.show()
fig.savefig("fig1c.png", dpi=600)   # PNG format
