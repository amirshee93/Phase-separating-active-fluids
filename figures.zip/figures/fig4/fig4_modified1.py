import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import matplotlib.ticker as ticker

plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'Helvetica'
ngrid = 500
fontsize = 26
markersize = 9
cmap = plt.cm.RdBu

fig = plt.figure(figsize=(8, 6))
ax1 = plt.subplot2grid((1, 1), (0, 0))
ax1.tick_params(labelsize=22)

# Set y-axis ticks 
tick_positions = [2, 2.5, 3, 3.5]
tick_labels = [r'$2.0$', r'$2.5$', r'$3.0$', r'$3.5$']
ax1.set_yticks(tick_positions)
ax1.set_yticklabels(tick_labels)
minor_locator = ticker.AutoMinorLocator(5)
ax1.yaxis.set_minor_locator(minor_locator)

# Set x-axis ticks 
tick_positions = [0, 0.5, 1]
tick_labels = [r'$0$', r'$0.5$', r'$1$']
ax1.set_xticks(tick_positions)
ax1.set_xticklabels(tick_labels)
minor_locator = ticker.AutoMinorLocator(5)
ax1.xaxis.set_minor_locator(minor_locator)

# Adjust margins
left_margin = 0.1   
right_margin = 0.97  
bottom_margin = 0.125 
top_margin = 0.96    
wspace = 0.25
hspace = 0.25
plt.subplots_adjust(left=left_margin, right=right_margin, bottom=bottom_margin, top=top_margin, wspace=wspace, hspace=hspace)

def read_two_column_file(file_name):
    with open(file_name, 'r') as data:
        x1, x2 = [], []
        for line in data:
            p = line.split()
            x1.append(float(p[0]))
            x2.append(float(p[1]))
    return x1, x2

# Model parameters
D = 0.1
rho0 = 1.0
wo = 1.0         # omega_off
alpha = 10.0

# Define the critical Pe function:
def critical_Pe(won):
    """
    Compute the critical Péclet number:
      Pe_c = ((1+q_c^2)/((1+alpha*wo)*psi0*fpsi))*(1+D + (wo+won)/q_c^2)
    where:
      q_c = ((wo+won)/(1+D))^(1/4),
      psi0 = (won/(wo+won))*rho0, and fpsi = 1/(1+psi0)^2.
    """
    psi0 = (won/(wo+won))*rho0
    fpsi = 1/(1+psi0)**2
    q_c = ((wo+won)/(1+D))**(1/4)
    return (1+q_c**2)/((1+alpha*wo)*psi0*fpsi) * (1+D + (wo+won)/(q_c**2))

# Define physical system parameters for q-range
L = 2*np.pi   # system size
a = 0.2       # microscopic cutoff
q_min = 2*np.pi / L          # smallest relevant q
q_max_endpoint = 2*np.pi / a # largest relevant q
Nq = 1000   # number of q samples
q_range = np.linspace(q_min, q_max_endpoint, Nq)

# ------------------------------------------------------------------
# Define functions that compute the growth rate for a given q
def function_lambda_real_q(q_val, won, Pe):
    """
    Computes the real part of the growth rate λ(q) for given q, ω_on (won), and Pe.
    """
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = Pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    m11 = -(q_val**2)*(1.0 - (B/(1+q_val**2))) - wo
    m22 = -(q_val**2)*D - won
    m12 = won
    m21 = -(q_val**2)*(-((Pe*(phi0 - alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q_val**2))) + wo
    trace = m11 + m22
    det = m11*m22 - m12*m21
    delta = trace**2 - 4.0 * det
    if delta < 0:
        lam = trace/2.0
    else:
        lam = np.real((trace + np.sqrt(delta))/2.0)
    return lam

def function_lambda_im_q(q_val, won, Pe):
    """
    Computes the imaginary part of the growth rate λ(q) for given q, ω_on (won), and Pe.
    """
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = Pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    m11 = -(q_val**2)*(1.0 - (B/(1+q_val**2))) - wo
    m22 = -(q_val**2)*D - won
    m12 = won
    m21 = -(q_val**2)*(-((Pe*(phi0 - alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q_val**2))) + wo
    trace = m11 + m22
    det = m11*m22 - m12*m21
    delta = trace**2 - 4.0 * det
    if delta < 0:
        lam_im = np.sqrt(-delta)/2.0
    else:
        lam_im = 0
    return lam_im

def function_lambdap_real_q(q_val, won, Pe):
    """
    Computes the real part of the secondary eigenvalue (lambdap) at given q.
    """
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = Pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    m11 = -(q_val**2)*(1.0 - (B/(1+q_val**2))) - wo
    m22 = -(q_val**2)*D - won
    m12 = won
    m21 = -(q_val**2)*(-((Pe*(phi0 - alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q_val**2))) + wo
    p11 = (m11 + m21 + m12 + m22) / 2.0
    p12 = (m11 + m21 - m12 - m22) / 2.0
    p21 = (m11 - m21 + m12 - m22) / 2.0
    p22 = (m11 - m21 - m12 + m22) / 2.0
    tracep = p11 + p22
    detp = p11*p22 - p12*p21
    deltap = tracep**2 - 4.0 * detp
    if deltap < 0:
        lampr = tracep/2.0
    else:
        lampr = np.real((tracep + np.sqrt(deltap))/2.0)
    return lampr

def function_lambdap_im_q(q_val, won, Pe):
    """
    Computes the imaginary part of the secondary eigenvalue (lambdap) at given q.
    """
    psi0 = (won/(wo+won))*rho0
    phi0 = (wo/(wo+won))*rho0
    A = 1 + D
    B = Pe*(1+alpha*wo)*(psi0/(1+psi0)**2)
    m11 = -(q_val**2)*(1.0 - (B/(1+q_val**2))) - wo
    m22 = -(q_val**2)*D - won
    m12 = won
    m21 = -(q_val**2)*(-((Pe*(phi0 - alpha*wo*psi0)*(1/(1+psi0)**2))/(1+q_val**2))) + wo
    p11 = (m11 + m21 + m12 + m22) / 2.0
    p12 = (m11 + m21 - m12 - m22) / 2.0
    p21 = (m11 - m21 + m12 - m22) / 2.0
    p22 = (m11 - m21 - m12 + m22) / 2.0
    tracep = p11 + p22
    detp = p11*p22 - p12*p21
    deltap = tracep**2 - 4.0 * detp
    if detp < 0:
        lampr_im = p11
    else:
        lampr_im = 0
    return lampr_im

# ------------------------------------------------------------------
# For each (won, Pe) pair, compute the optimized growth rates by scanning over q_range.
won_values = np.linspace(0.0, 1.1, ngrid)
Pe_values = np.linspace(2, 3.75, ngrid)

lambda_real = np.zeros((len(won_values), len(Pe_values)))
lambda_im = np.zeros((len(won_values), len(Pe_values)))
lambdap_real = np.zeros((len(won_values), len(Pe_values)))
lambdap_im = np.zeros((len(won_values), len(Pe_values)))
qmax_array = np.zeros((len(won_values), len(Pe_values)))  # store q_max for each (won, Pe)

for j, won in enumerate(won_values):
    for i, Pe in enumerate(Pe_values):
        lam_vals = np.array([function_lambda_real_q(q, won, Pe) for q in q_range])
        max_idx = np.argmax(lam_vals)
        q_opt = q_range[max_idx]
        qmax_array[j, i] = q_opt
        lambda_real[j, i] = lam_vals[max_idx]
        lam_im_vals = np.array([function_lambda_im_q(q, won, Pe) for q in q_range])
        lambda_im[j, i] = lam_im_vals[max_idx]
        lampr_vals = np.array([function_lambdap_real_q(q, won, Pe) for q in q_range])
        lambdap_real[j, i] = lampr_vals[max_idx]
        lampr_im_vals = np.array([function_lambdap_im_q(q, won, Pe) for q in q_range])
        lambdap_im[j, i] = lampr_im_vals[max_idx]

# ------------------------------------------------------------------
# Plot the heat map of q_max (the optimal wave number) on the won-Pe plane.
fig, ax1 = plt.subplots(figsize=(8, 6))
c = ax1.contourf(won_values, Pe_values, qmax_array.T, 200, cmap='RdBu')
ax1.set_xlabel(r'$\omega_{\mathrm{on}}$', fontsize=fontsize)
ax1.set_ylabel(r'$Pe$', fontsize=fontsize)
cb = fig.colorbar(c, ax=ax1)
cb.set_label(r'$q_{\rm max}$', fontsize=fontsize)
cb.ax.tick_params(which='both', direction='in', labelsize=14)
ax1.xaxis.set_minor_locator(ticker.AutoMinorLocator())
ax1.yaxis.set_minor_locator(ticker.AutoMinorLocator())
ax1.tick_params(which='both', direction='in', labelsize=14)

# --- Plot the critical Pe curve (only in the oscillatory regime) ---
won_line = []
Pe_crit_line = []
for won in won_values:
    Pe_c = critical_Pe(won)
    # For each won, we check the imaginary part at the q that maximizes the real growth rate.
    q_opt_index = np.argmax([function_lambda_real_q(q, won, Pe_c) for q in q_range])
    q_opt_at_Pec = q_range[q_opt_index]
    if function_lambda_im_q(q_opt_at_Pec, won, Pe_c) > 0:
        won_line.append(won)
        Pe_crit_line.append(Pe_c)

if won_line:
    ax1.plot(won_line, Pe_crit_line, '--', color='m', linewidth=3, label=r'$\mathbf{Pe_c~(Eq.~(10))}$')

# --- Label the figure as (c) ---
ax1.text(0.05, 0.95, r'(c)', transform=ax1.transAxes, fontsize=20, verticalalignment='top', horizontalalignment='left')

plt.tight_layout()
plt.show()
fig.savefig("fig4_modified.png", dpi=600)
