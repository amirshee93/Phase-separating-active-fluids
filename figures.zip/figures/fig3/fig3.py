import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import matplotlib.ticker as ticker
from matplotlib.ticker import MultipleLocator

# Set Parameters
plt.rcParams['text.usetex'] = True
plt.rcParams['font.family'] = 'Helvetica'
plt.rcParams['text.latex.preamble'] = r'\usepackage[usenames,dvipsnames]{xcolor}'

fontsize = 28
cmap = plt.cm.RdBu

# Create figure and subplots
fig = plt.figure(figsize=(8, 6))
ax1 = plt.subplot2grid((2, 2), (0, 0))
ax2 = plt.subplot2grid((2, 2), (0, 1))
ax3 = plt.subplot2grid((2, 2), (1, 0))
ax4 = plt.subplot2grid((2, 2), (1, 1))

# Configure ticks and labels for all axes
for ax in [ax1, ax2, ax3, ax4]:
    ax.tick_params(labelsize=20)
    ax.set_xticks([0, np.pi, 2*np.pi])
    ax.set_xticklabels([r'$0$', r'$\pi$', r'$2\pi$'])
    ax.xaxis.set_minor_locator(ticker.AutoMinorLocator(2))
    # Set both major and minor ticks inward, on all sides
    ax.tick_params(which='major', direction='in', bottom=True, top=True, left=True, right=True)
    ax.tick_params(which='minor', direction='in', bottom=True, top=True, left=True, right=True)

ax2.yaxis.set_major_locator(MultipleLocator(0.5))
plt.subplots_adjust(left=0.095, right=0.97, bottom=0.09, top=0.98, wspace=0.25, hspace=0.25)

# ---------- First Dataset (Panels a and c) ----------
pe = 3.5
won = 0.15
w0 = 1.0
alpha = 10.0
subdir = '/Users/amirshee/my_work/active_fluids/numerics/one_dimension/won_0.15/pe_3.5/dynamics_data/concentrations_velocity_900.csv'
df = pd.read_csv(subdir)
x = df['xval'].values
ca = df[' caval'].values
cp = df[' cpval'].values
v = df[' vval'].values

# Panel (a): Concentration plots
ax1.plot(x, ca, color='darkred', linestyle='-', linewidth=4, label=r'$\psi$')
ax1.plot(x, cp, color='darkblue', linestyle='-', linewidth=2, label=r'$\phi$')
ax1.fill_between(x, 0, ca, color='darkred', alpha=0.1)
ax1.fill_between(x, 0, cp, color='darkblue', alpha=0.1)
ax1.text(-0.24, 0.49, r'$\psi,~$', transform=ax1.transAxes, fontsize=fontsize, fontweight='bold',
         va='top', color='darkred', rotation=90)
ax1.text(-0.24, 0.59, r'$\phi$', transform=ax1.transAxes, fontsize=fontsize, fontweight='bold',
         va='top', color='darkblue', rotation=90)
ax1.set_xlim([0, 2*np.pi])
ax1.set_ylim([0, 1.6])
ax1.text(0.025, 0.95, '(a)', transform=ax1.transAxes, fontsize=fontsize, fontweight='bold', va='top')

# Panel (c): Plot velocity, its first derivative, and its second derivative together on the same axis
dv_dx = np.gradient(v, x)
d2v_dx2 = np.gradient(dv_dx, x)
ax3.plot(x, v, color='k', linestyle='-', linewidth=2.5)
ax3.plot(x, dv_dx, color='darkviolet', linestyle='--', linewidth=2.5)
ax3.plot(x, d2v_dx2, color='darkgreen', linestyle='-.', linewidth=2.5)
ax3.set_xlim([0, 2*np.pi])
ax3.set_ylim([-0.32, 0.32])
ax3.set_xlabel('$x$', fontsize=fontsize, labelpad=-7)
ax3.text(-0.25, 0.35, r'$v,~$', transform=ax3.transAxes, fontsize=fontsize, fontweight='bold',
         va='top', color='k', rotation=90)
ax3.text(-0.25, 0.59, r'$\sigma_p,~$', transform=ax3.transAxes, fontsize=fontsize, fontweight='bold',
         va='top', color='darkviolet', rotation=90)
ax3.text(-0.24, 0.75, r'$f_p$', transform=ax3.transAxes, fontsize=fontsize, fontweight='bold',
         va='top', color='darkgreen', rotation=90)
ax3.text(0.025, 0.95, '(c)', transform=ax3.transAxes, fontsize=fontsize, fontweight='bold', va='top')

# ---------- Second Dataset (Panels b and d) ----------
pe = 3.0
won = 0.5
w0 = 1.0
alpha = 10.0
subdir = '/Users/amirshee/my_work/active_fluids/numerics/one_dimension/won_0.5/pe_3.0/dynamics_data/concentrations_velocity_900.csv'
df = pd.read_csv(subdir)
x = df['xval'].values
ca = df[' caval'].values
cp = df[' cpval'].values
v = df[' vval'].values

# Panel (b): Concentration plots
ax2.plot(x, ca, color='darkred', linestyle='-', linewidth=4, label=r'$\psi$')
ax2.plot(x, cp, color='darkblue', linestyle='-', linewidth=2, label=r'$\phi$')
ax2.fill_between(x, 0, ca, color='darkred', alpha=0.1)
ax2.fill_between(x, 0, cp, color='darkblue', alpha=0.1)
ax2.set_xlim([0, 2*np.pi])
ax2.set_ylim([0, 1.25])
ax2.text(0.05, 0.95, '(b)', transform=ax2.transAxes, fontsize=fontsize, fontweight='bold', va='top')

# Panel (d): Plot velocity, its first derivative, and its second derivative together on the same axis
dv_dx2 = np.gradient(v, x)
d2v_dx2_2 = np.gradient(dv_dx2, x)
ax4.plot(x, v, color='k', linestyle='-', linewidth=2.5)
ax4.plot(x, dv_dx2, color='darkviolet', linestyle='--', linewidth=2.5)
ax4.plot(x, d2v_dx2_2, color='darkgreen', linestyle='-.', linewidth=2.5)
ax4.set_xlim([0, 2*np.pi])
ax4.set_ylim([-0.6, 0.6])
ax4.set_xlabel('$x$', fontsize=fontsize, labelpad=-7)
ax4.text(0.05, 0.95, '(d)', transform=ax4.transAxes, fontsize=fontsize, fontweight='bold', va='top')

plt.show()
fig.savefig("fig3.png", dpi=600)
